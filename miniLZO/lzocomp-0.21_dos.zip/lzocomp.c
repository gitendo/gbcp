/* testmini.c -- very simple test program for the miniLZO library

   This file is part of the LZO real-time data compression library.

   Copyright (C) 1998 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1997 Markus Franz Xaver Johannes Oberhumer
   Copyright (C) 1996 Markus Franz Xaver Johannes Oberhumer

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of
   the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with the LZO library; see the file COPYING.
   If not, write to the Free Software Foundation, Inc.,
   59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Markus F.X.J. Oberhumer
   markus.oberhumer@jk.uni-linz.ac.at
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "minilzo.h"

/* Work-memory needed for compression. Allocate memory in units
 * of `long' (instead of `char') to make sure it is properly aligned.
 */

#define HEAP_ALLOC(var,size) \
	long __LZO_MMODEL var [ ((size) + (sizeof(long) - 1)) / sizeof(long) ]

static HEAP_ALLOC(wrkmem,LZO1X_1_MEM_COMPRESS);

int main(int argc, char *argv[])
{
	int i;
	char in_filename[100];
	char out_filename[100];
	unsigned char *in_buf, *out_buf;
	char *dot;
	lzo_uint file_len, out_len;
	FILE *in_FP, *out_FP;
	
	in_filename[0]='\0';
	out_filename[0]='\0';
	
	printf("lzocomp 0.21 - compress file using minilzo\n"
	       "  Quick hack by Michael Hope <michaelh@earthling.net (C) 1998\n"
	       "  Uses LZO real-time data compression library (v%s, %s).\n"
	       "     Copyright (C) 1996, 1997, 1998 Markus Franz Xaver Johannes Oberhumer\n",
	        LZO_VERSION_STRING, LZO_VERSION_DATE);

	if (lzo_init() != LZO_E_OK) {
		fprintf(stderr, "error: Initilization failed.\n");
		return -1;
	}

	for (i=1; i<argc; i++) {
		if (!strcmp("-o", argv[i])) {
			/* Specifies output file */
			i++;
			if (i<argc) {
				if (strlen(out_filename)==0) {
					strcpy( out_filename, argv[i]);
				}
				else
					fprintf(stderr,"warning: ignoring extra -o\n");
			}
			else 
				fprintf(stderr,"warning: no argument to -o\n");
		}
		else {
			if (strlen(in_filename)==0) {
				strcpy( in_filename, argv[i]);
			}
			else
				fprintf(stderr, "warning: extra source file %s ignored.\n", argv[i]);
		}
	}

	if (strlen(in_filename)!=0) {
		if (strlen(out_filename)==0) {
			/* Make a .lzo file from a .any file */
			if ((dot=strrchr(in_filename, '.'))!=NULL)
				*dot='\0';
			strcpy( out_filename, in_filename);
			strcat( out_filename, ".lzo");
			if (dot!=NULL)
				*dot='.';
		}
		in_FP=fopen(in_filename, "rb");
		if (in_FP) {
			fseek( in_FP, 0, SEEK_END);
			file_len = ftell(in_FP);
			rewind(in_FP);

			in_buf = malloc(file_len+1);
			if (in_buf) {
				/* Done this way to remove optimisation trouble */
				fread(in_buf,1,file_len, in_FP);
				out_buf = malloc(file_len+(file_len/5));
				if (out_buf) {
					if (lzo1x_1_compress(in_buf,file_len,out_buf,&out_len,wrkmem)==LZO_E_OK) {
						printf("Compressed %lu bytes into %lu bytes\n", file_len, out_len );
						out_FP=fopen(out_filename,"wb");
						if (out_FP) {
							fwrite( out_buf, 1, out_len, out_FP);
						}
						else {
							fprintf(stderr, "Error: Cannot write to file %s.\n", out_filename );
							return -5;
						}
						fclose(out_FP);
					}
					free(out_buf);
				}
				else {
					fprintf(stderr,"error: Cannot allocate enough memory for output buffer.\n");
					free(in_buf);
					return -4;
				}
				free(in_buf);
			}
			else {
				fprintf(stderr,"error: Cannot allocate enough memory to read input.\n");
				return -3;
			}
			fclose(in_FP);
		}
	}
	else {
		fprintf(stderr, "Error: No input filename specified.\n");
		return -6;
	}
	return 0;
}
